#ifndef __BOARD_H
#define __BOARD_H

#include "stm32f10x.h"

void clock_init(void);
void gpio_init(void);
void board_init(void);

#endif
