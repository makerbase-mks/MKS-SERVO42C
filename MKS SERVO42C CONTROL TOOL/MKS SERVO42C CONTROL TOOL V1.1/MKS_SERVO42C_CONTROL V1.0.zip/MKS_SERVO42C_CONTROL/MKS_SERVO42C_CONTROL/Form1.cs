﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace MKS_SERVO42C_CONTROL
{
    public partial class Form1 : Form
    {
        byte DataSended;
        byte Readata;
        byte[] Buffer;
        string str;
        byte[] QueryCommand = new byte[] { 0x30, 0x33, 0x36, 0x39, 0x3A, 0x3E, 0xF3, 0xF3, 0xF6, 0xF7, 0xFF, 0xFF, 0x84, 0xFD };                     //读取参数指令
        byte FWD = 0x00;            //正转
        byte RWD = 0x80;            //反转
        byte STOP = 0xF7;           //停止转动
        byte EN_ON = 0x01;          //使能主板

        byte EN_OFF = 0x00;         //关闭主板
        byte Save_Speed = 0xC8;     //保存所设置的正/反转速度
        byte Clear_Speed = 0xCA;    //清除所设置的正/反转速度
        byte Speed;                 //速度档位1
        byte Speed2;                 //速度档位2
        ushort Subdivision;         //细分
        byte[] Pulse;               //脉冲数

        //状态接收
        byte EN_STATE_ON = 0x01;        //使能状态
        byte EN_STATE_OFF = 0x02;       //未使能状态
        byte Stall_YES = 0x01;          //堵转
        byte Stall_ON = 0x02;           //正常

        //语言转换
        string[] ConnectText1 = { "断开失败，请再次尝试", "Disconnect failed, please try again" };
        string Text1_Connect;

        string[] WindowText1 = { "错误", "error" };
        string Text1_window;

        string[] WindowText2 = { "警告", "Warning" };
        string Text2_window;

        string[] ConnectText2 = { "连接失败，请检查串口", "Connection failed, please check the serial port" };
        string Text2_Connect;

        string[] SerialErrorText1 = { "串口数据发送出错，请检查。", "Serial data transmission error, please check." };
        string Text1_SerialError;

        string[] Direction_Text = { "警告：没有选择正反转，将默认正转", "Warning: if forward and reverse is not selected, the default will be forward." };
        string Text1_Direction;

        string[] Speedgear_Text1 = { "错误：速度档位应为0-127。", "Error: The speed gear should be 0-127." };
        string Text1_Speedgear;

        string[] SubdivisionError_Text1 = { "错误：任意细分范围应在1-256。", "Error: Any subdivision range should be 1-256." };
        string Text1_SubdivisionError;

        string[] PulseError_Text1 = { "错误：脉冲数为16位，即0-65535", "Error: number of pulses is 16 bits, 0-65535" };
        string Text1_PulseError;

        string[] DataError_Text1 = { "警告：请选择数据类型", "Warning: Please select the data type." };
        string Text1_DataError;

        string[] EN_Text1 = { "使能", "Enable" };
        string Text1_EN;

        string[] EN_Text2 = { "没使能", "Disable" };
        string Text2_EN;

        string[] Stall_Text1 = { "堵转", "Blocked" };
        string Text1_Stall;

        string[] Stall_Text2 = { "正常", "Unblocked" };
        string Text2_Stall;

        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                    comboBox1.Enabled = true;
                    comboBox2.Enabled = true;
                }
                catch
                {
                    MessageBox.Show(Text1_Connect, Text1_window);
                }
                button1.Enabled = true;
                button18.Enabled = false;
            }
            else
            {
                try
                {
                    serialPort1.PortName = comboBox1.Text;
                    serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text, 10);//十进制数据转换
                    serialPort1.Open();
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    button1.Enabled = false;
                    button18.Enabled = true;
                }
                catch
                {
                    MessageBox.Show(Text2_Connect, Text1_window);
                }
            }
        }
        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
            }
            catch
            {
                MessageBox.Show(Text1_Connect, Text1_window);
            }

            button1.Enabled = true;
            button18.Enabled = false;
        }
        private void Button_Click(object sender, EventArgs e)                            //按键共用一个处理函数
        {
            Button MyButton = (Button)sender;
            DataSended = Convert.ToByte(MyButton.Tag);
            SendRelevantData(QueryCommand[DataSended]);
        }
        private void WriteByteToSerialPort(byte[] data, byte start, byte length)
        {    //字节发送
            if (serialPort1.IsOpen)                                     //传输数据的前提是端口已打开
            {
                try
                {
                    serialPort1.Write(data, start, length);                    //写数据
                }
                catch
                {
                    MessageBox.Show(Text1_SerialError, Text1_window);//错误处理
                }
            }
            else
                MessageBox.Show(Text1_SerialError, Text1_window);//错误处理
        }
        private void SendRelevantData(byte data)                  //判断数据类型，并且发送
        {
            byte Addr = Convert.ToByte(comboBox5.Text, 16);         //获取主板通讯地址
            byte SpeedText;                                     //速度档位变量
            byte SpeedText2;                                     //速度档位变量
            ushort SubdivisionText;                               //细分值变量
            int PulseText;                                       //脉冲变量
            try
            {
                if (DataSended < 6)
                {
                    Buffer = new byte[] { Addr, data };                       //定义数组
                    WriteByteToSerialPort(Buffer, 0, 2);

                }
                if (DataSended > 5 && DataSended < 8)                   //使能或者关闭主板
                {
                    if (DataSended == 6)                                //使能主板
                    {
                        Buffer = new byte[] { Addr, data, EN_ON };
                        button10.Enabled = false;
                        button9.Enabled = true;
                    }
                    else                                                //关闭主板
                    {
                        Buffer = new byte[] { Addr, data, EN_OFF };
                        button9.Enabled = false;
                        button10.Enabled = true;
                    }
                    WriteByteToSerialPort(Buffer, 0, 3);
                }
                if (DataSended == 8)                                        //电机运行
                {
                    SpeedText = Convert.ToByte(comboBox3.Text, 10);         //获取速度档位值
                    if (SpeedText < 128 && SpeedText >= 0)
                    {
                        if (radioButton2.Checked)                          //以SpeedText档速度反转
                        {
                            Speed = Convert.ToByte(SpeedText | RWD);
                            Buffer = new byte[] { Addr, data, Speed };
                            //Console.WriteLine(Speed);
                        }
                        else if (radioButton1.Checked)                      //以SpeedText档速度正转
                        {
                            Speed = Convert.ToByte(SpeedText | FWD);
                            Buffer = new byte[] { Addr, data, Speed };
                            //Console.WriteLine(Speed);
                        }
                        else                                                //以SpeedText档速度正转,并警告
                        {
                            MessageBox.Show(Text1_Direction, Text2_window);//错误处理
                            Speed = Convert.ToByte(SpeedText | FWD);
                            Buffer = new byte[] { Addr, data, Speed };
                            //Console.WriteLine(Speed);
                        }
                        WriteByteToSerialPort(Buffer, 0, 3);
                    }
                    else
                        MessageBox.Show(Text1_Speedgear, Text1_window);//错误处理
                }

                if (DataSended == 9)
                {
                    Buffer = new byte[] { Addr, STOP };
                    WriteByteToSerialPort(Buffer, 0, 2);
                }

                if (DataSended == 10)
                {
                    Buffer = new byte[] { Addr, data, Save_Speed };
                    WriteByteToSerialPort(Buffer, 0, 3);
                    Console.WriteLine(value: Save_Speed);
                }
                if (DataSended == 11)
                {
                    Buffer = new byte[] { Addr, data, Clear_Speed };
                    WriteByteToSerialPort(Buffer, 0, 3);
                }
                if (DataSended == 12)
                {
                    SubdivisionText = Convert.ToUInt16(textBox7.Text, 10);
                    Console.WriteLine(SubdivisionText);
                    if (SubdivisionText < 257 && SubdivisionText >= 1)
                    {
                        Subdivision = Convert.ToByte(SubdivisionText);
                        Buffer = new byte[] { Addr, data, (byte)Subdivision };
                        WriteByteToSerialPort(Buffer, 0, 3);
                    }
                    else
                        MessageBox.Show(Text1_SubdivisionError, Text1_window);//错误处理}
                }
                if (DataSended == 13)
                {
                    SpeedText2 = Convert.ToByte(comboBox4.Text, 10);         //获取速度档位值
                    PulseText = Convert.ToInt32(textBox8.Text, 10);
                    Pulse = BitConverter.GetBytes(PulseText);           //将int32转换为字节数组
                    /* Console.WriteLine(PulseText);
                     Console.WriteLine(Pulse[1]);
                     Console.WriteLine(Pulse[0]);*/
                    if (SpeedText2 < 128 && SpeedText2 >= 0)
                    {
                        if (PulseText < 65536 && PulseText >= 1)
                        {
                            if (radioButton4.Checked)                       //反转
                            {
                                Speed2 = Convert.ToByte(SpeedText2 | RWD);
                                //Pulse = Convert.ToByte(PulseText);
                                Buffer = new byte[] { Addr, data, Speed2, Pulse[1], Pulse[0] };
                            }
                            else if (radioButton3.Checked)                  //正转
                            {
                                Speed2 = Convert.ToByte(SpeedText2 | FWD);
                                //Pulse = Convert.ToByte(PulseText);
                                Buffer = new byte[] { Addr, data, Speed2, Pulse[1], Pulse[0] };
                            }
                            else                                                       //警告并默认正转
                            {
                                MessageBox.Show(Text1_Direction, Text2_window);  //错误处理
                                Speed2 = Convert.ToByte(SpeedText2 | FWD);
                                //Pulse = Convert.ToByte(PulseText);
                                Buffer = new byte[] { Addr, data, Speed2, Pulse[1], Pulse[0] };
                            }
                            WriteByteToSerialPort(Buffer, 0, 5);
                        }
                        else
                            MessageBox.Show(Text1_PulseError, Text1_window);//错误处理
                    }
                }
            }
            catch (Exception)
            { }
        }

        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)//串口数据接收事件
        {
            //接收模式为HEX格式接收

            byte Addr = Convert.ToByte(comboBox5.Text, 16);
            for (int i = 0; i < 5; i++)
            {
                Readata = (byte)serialPort1.ReadByte();//此处需要强制类型转换，将(int)类型数据转换为(byte类型数据，不必考虑是否会丢失数据
                                                       //str = Convert.ToString(Readata, 10).ToUpper();//转换为十进制字符串                
                switch (DataSended)
                {

                    case 0:                             //查询编码器值
                        if (Addr == Readata)                                                //如果重新再次接受数据则先清空
                        {
                            textBox1.Clear();
                            if (radioButton5.Checked)
                            {
                                textBox1.AppendText("0x");
                            }

                        }
                        else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串                                                                                          
                                textBox1.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {

                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox1.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }

                            //textBox1.AppendText(str );        //十进制显示
                            //Console.WriteLine("十六进制  的十进制表示: " + Convert.ToInt32(textBox1.Text , 16));                                              //
                        }
                        break;
                    case 1:                             //输入累积脉冲数
                        if (Addr == Readata)
                        {
                            textBox2.Clear();
                            if (radioButton5.Checked)
                            {
                                textBox2.AppendText("0x");
                            }
                        }
                        else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox2.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox2.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }

                        }
                        break;

                    case 2:                                 //电机位置
                        if (Addr == Readata)
                        {
                            textBox3.Clear();
                            if (radioButton5.Checked)
                            {
                                textBox3.AppendText("0x");
                            }
                        }
                        else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox3.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox3.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }
                        }
                        break;

                    case 3:                         //位置角度误差
                        if (Addr == Readata)
                        {
                            textBox4.Clear();
                            if (radioButton5.Checked)
                            {
                                textBox4.AppendText("0x");
                            }
                        }
                        else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox4.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox4.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }
                        }
                        break;

                    case 4:                                     //使能状态
                        if (Addr == Readata)
                        {
                            textBox5.Clear();
                        }
                        else if (Addr != Readata)
                        {
                            if (Readata == EN_STATE_ON)
                            {
                                textBox5.AppendText(Text1_EN);
                            }
                            else if (Readata == EN_STATE_OFF)
                            {
                                textBox5.AppendText(Text2_EN);
                            }
                        }
                        break;

                    case 5:                                     //堵转状态
                        if (Addr == Readata)
                        {
                            textBox6.Clear();
                        }
                        else if (Addr != Readata)
                        {
                            if (Readata == Stall_YES)
                            {
                                textBox6.AppendText(Text1_Stall);
                            }
                            else if (Readata == Stall_ON)
                            {
                                textBox6.AppendText(Text2_Stall);
                            }
                            //str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                            //textBox6.AppendText("0x" + (str.Length == 1 ? "0" + str : str) + " ");
                        }
                        break;
                }
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }



        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);       //扫描并讲课用串口添加至下拉列表
        }
        private void SearchAndAddSerialToComboBox(SerialPort MyPort, ComboBox MyBox)
        {                                                               //将可用端口号添加到ComboBox
            //string[] MyString = new string[20];                         //最多容纳20个，太多会影响调试效率
            string Buffer;                                              //缓存
            MyBox.Items.Clear();                                        //清空ComboBox内容

            for (int i = 1; i < 20; i++)                                //循环
            {
                try                                                     //核心原理是依靠try和catch完成遍历
                {
                    Buffer = "COM" + i.ToString();
                    MyPort.PortName = Buffer;
                    MyPort.Open();                                      //如果失败，后面的代码不会执行
                    MyBox.Items.Add(Buffer);                            //打开成功，添加至下俩列表
                    MyPort.Close();                                     //关闭
                }
                catch
                {

                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void Form1_Load_1(object sender, EventArgs e)
        {
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);
            comboBox2.Text = "38400";//波特率默认值
            comboBox5.Text = "0xE0";
            comboBox3.Text = "000";
            comboBox4.Text = "000";
            textBox8.Text = "0";
            /*****************非常重要************************/
            groupBox1.Text = "Setting";
            groupBox2.Text = "Read parameters";
            groupBox3.Text = "Set any subdivision";
            groupBox4.Text = "Control";
            groupBox5.Text = "Control motor rotation";
            groupBox6.Text = "Control motor position";

            label10.Text = "Tip: speed range 1-128";
            label1.Text = "Input";
            label2.Text = "Port";
            label3.Text = "Baud rate";
            label4.Text = "Speed gear";
            label5.Text = "Speed gear";
            label6.Text = "Pulses number";
            label7.Text = "Tip: At 16 subdivision, 3200 pulses = 360°";
            label8.Text = "Tip: Segmentation range 1-256";
            label9.Text = "Address";

            button1.Text = "Connect";
            button2.Text = "Verify";
            button3.Text = "Encoder value";
            button4.Text = "Cumulative pulse number";
            button5.Text = "Motor position";
            button6.Text = "Position angle error";
            button7.Text = "Driver board enable state";
            button8.Text = "Blocked";
            button9.Text = "Disable enable";
            button10.Text = "Enable driver board";
            button11.Text = "Start";
            button12.Text = "Stop";
            button13.Text = "Turn on automatic operation after power-on";
            button14.Text = "Turn off automatic operation after power-on";
            button15.Text = "Start";
            button16.Text = "Stop";
            button17.Text = "Scan";
            button18.Text = "Disconnect";

            radioButton1.Text = "Forward";
            radioButton2.Text = "Reverse";
            radioButton3.Text = "Forward";
            radioButton4.Text = "Reverse";
            radioButton5.Text = "Hex";
            radioButton6.Text = "Decimal";

            语言ToolStripMenuItem.Text = "Language";

            Text1_Connect = ConnectText1[1];
            Text1_window = WindowText1[1];
            Text2_window = WindowText2[1];
            Text2_Connect = ConnectText2[1];
            Text1_SerialError = SerialErrorText1[1];
            Text1_Direction = Direction_Text[1];
            Text1_Speedgear = Speedgear_Text1[1];
            Text1_SubdivisionError = SubdivisionError_Text1[1];
            Text1_PulseError = PulseError_Text1[1];
            Text1_DataError = DataError_Text1[1];
            Text1_EN = EN_Text1[1];
            Text2_EN = EN_Text2[1];
            Text1_Stall = Stall_Text1[1];
            Text2_Stall = Stall_Text2[1];

            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);//必须手动添加事件处理程序
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void 设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 中文ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            groupBox1.Text = "连接设置";
            groupBox2.Text = "读取参数";
            groupBox3.Text = "设置任意细分";
            groupBox4.Text = "控制";
            groupBox5.Text = "控制电机正反转";
            groupBox6.Text = "控制电机位置";

            label10.Text = "提示：速度档位范围1-128";
            label1.Text = "输入细分";
            label2.Text = "串  口";
            label3.Text = "波特率";
            label4.Text = "速度档位";
            label5.Text = "速度档位";
            label6.Text = "脉冲数";
            label7.Text = "提示：在16细分时，3200脉冲 = 360°";
            label8.Text = "提示：细分范围1-256";
            label9.Text = "通讯地址";

            button1.Text = "连接主板";
            button2.Text = "确认";
            button3.Text = "编码器值";
            button4.Text = "输入累计脉冲数";
            button5.Text = "电机位置";
            button6.Text = "位置角度误差";
            button7.Text = "驱动板使能状态";
            button8.Text = "堵转标志位";
            button9.Text = "关闭驱动板";
            button10.Text = "使能驱动板";
            button11.Text = "开始";
            button12.Text = "停止";
            button13.Text = "开启上电自动运行";
            button14.Text = "关闭上电自动运行";
            button15.Text = "开始";
            button16.Text = "停止";
            button17.Text = "扫描";
            button18.Text = "断开连接";

            radioButton1.Text = "正转";
            radioButton2.Text = "反转";
            radioButton3.Text = "正转";
            radioButton4.Text = "反转";
            radioButton5.Text = "十六进制";
            radioButton6.Text = "十进制";

            语言ToolStripMenuItem.Text = "语言";

            Text1_Connect = ConnectText1[0];
            Text2_Connect = ConnectText2[0];
            Text1_window = WindowText1[0];
            Text2_window = WindowText2[0];
            Text1_SerialError = SerialErrorText1[0];
            Text1_Direction = Direction_Text[0];
            Text1_Speedgear = Speedgear_Text1[0];
            Text1_SubdivisionError = SubdivisionError_Text1[0];
            Text1_PulseError = PulseError_Text1[0];
            Text1_DataError = DataError_Text1[0];
            Text1_EN = EN_Text1[0];
            Text2_EN = EN_Text2[0];
            Text1_Stall = Stall_Text1[0];
            Text2_Stall = Stall_Text2[0];
        }

        private void englishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Text = "Setting";
            groupBox2.Text = "Read parameters";
            groupBox3.Text = "Set any subdivision";
            groupBox4.Text = "Control";
            groupBox5.Text = "Control motor rotation";
            groupBox6.Text = "Control motor position";

            label10.Text = "Tip: speed range 1-128";
            label1.Text = "Input";
            label2.Text = "Port";
            label3.Text = "Baud rate";
            label4.Text = "Speed gear";
            label5.Text = "Speed gear";
            label6.Text = "Pulses number";
            label7.Text = "Tip: At 16 subdivision, 3200 pulses = 360°";
            label8.Text = "Tip: Segmentation range 1-256";
            label9.Text = "Address";

            button1.Text = "Connect";
            button2.Text = "Verify";
            button3.Text = "Encoder value";
            button4.Text = "Cumulative pulse number";
            button5.Text = "Motor position";
            button6.Text = "Position angle error";
            button7.Text = "Driver board enable state";
            button8.Text = "Blocked";
            button9.Text = "Disable enable";
            button10.Text = "Enable driver board";
            button11.Text = "Start";
            button12.Text = "Stop";
            button13.Text = "Turn on automatic operation after power-on";
            button14.Text = "Turn off automatic operation after power-on";
            button15.Text = "Start";
            button16.Text = "Stop";
            button17.Text = "Scan";
            button18.Text = "Disconnect";

            radioButton1.Text = "Forward";
            radioButton2.Text = "Reverse";
            radioButton3.Text = "Forward";
            radioButton4.Text = "Reverse";
            radioButton5.Text = "Hex";
            radioButton6.Text = "Decimal";

            语言ToolStripMenuItem.Text = "Language";

            Text1_Connect = ConnectText1[1];
            Text1_window = WindowText1[1];
            Text2_window = WindowText2[1];
            Text2_Connect = ConnectText2[1];
            Text1_SerialError = SerialErrorText1[1];
            Text1_Direction = Direction_Text[1];
            Text1_Speedgear = Speedgear_Text1[1];
            Text1_SubdivisionError = SubdivisionError_Text1[1];
            Text1_PulseError = PulseError_Text1[1];
            Text1_DataError = DataError_Text1[1];
            Text1_EN = EN_Text1[1];
            Text2_EN = EN_Text2[1];
            Text1_Stall = Stall_Text1[1];
            Text2_Stall = Stall_Text2[1];
        }
    }
}
