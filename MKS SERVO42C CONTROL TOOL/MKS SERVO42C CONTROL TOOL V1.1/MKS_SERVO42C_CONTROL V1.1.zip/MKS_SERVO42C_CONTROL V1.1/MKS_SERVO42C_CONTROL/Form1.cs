﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace MKS_SERVO42C_CONTROL
{
    public partial class Form1 : Form
    {
        byte DataSended;
        string word16;
        short data16;
        string word32;
        int data32;
        string Text_BUF;

        int tCHK;
        byte Readata;
        byte[] Buffer;
        byte[] SerialBuffer_RX;
        int Data_Number;
        string str;

        //指令
        int[] QueryCommand = new int[] { 0x30, 0x33, 0x36, 0x39, 0x3A, 0x3E, 0xF3, 0xF3, 0xF6, 0xF7,
                                        0xFF, 0xFF, 0x84, 0xFD, 0x80, 0x81, 0x82, 0X83, 0x85, 0x86,
                                        0x87, 0x88, 0x89, 0x8A, 0x8B, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5,
                                        0x90, 0x90, 0x91, 0x92, 0x93, 0x94, 0x3F };

        //常用字节
        byte[] byte_data = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };

        //功能字节
        byte FWD = 0x00;           
        byte RWD = 0x80;           
        byte STOP = 0xF7;          
        byte EN_ON = 0x01;         
        byte EN_OFF = 0x00;        
        byte Save_Speed = 0xC8;     
        byte Clear_Speed = 0xCA;    

        //数据
        byte Speed;                
        byte Speed2;                
        ushort Subdivision;         
        byte[] Pulse;            
        byte[] Kp;                  
        byte[] Ki;
        byte[] Kd;
        byte[] ACC;
        byte[] MaxT;

        //状态接收
        byte EN_STATE_ON = 0x01;       
        byte EN_STATE_OFF = 0x02;       
        byte Stall_YES = 0x01;          
        byte Stall_ON = 0x02;         

        //状态字符串
        string Mot_18 = "1.8°";
        string Mot_09 = "0.9°";
        string CR_OPEN = "CR_OPEN";
        string CR_vFOC = "CR_LOOP";
        string CR_UART = "CR_UART";
        string[] I_Ma = { "0", "200", "400", "600", "800", "1000", "1200", "1400", "1600", "1800", "2000", "2200", "2400", "2600", "2800", "3000" };
        string EN_H = "H";
        string EN_L = "L";
        string EN_Hold = "Hold";
        string Dir_CW = "CW";
        string Dir_CCW = "CCW";
        string Disable = "Disable";
        string Enable = "Enable";
        string[] UartBaud = { "9600", "19200", "25000", " 38400", "57600", " 115200" };
        string[] UartAddr = { "0xE0", "0xE1", "0xE2", "0xE3", "0xE4", "0xE5", "0xE6", "0xE7", "0xE8", "0xE9" };

        //语言转换

        string[] ConnectText1 = { "断开失败，请再次尝试", "Disconnect failed, please try again" };
        string Text1_Connect;

        string[] WindowText1 = { "错误", "error" };
        string Text1_window;

        string[] WindowText2 = { "警告", "Warning" };
        string Text2_window;

        string[] ConnectText2 = { "连接失败，请检查串口", "Connection failed, please check the serial port" };
        string Text2_Connect;

        string[] SerialErrorText1 = { "串口数据发送出错，请检查。", "Serial data transmission error, please check." };
        string Text1_SerialError;

        string[] Direction_Text = { "警告：没有选择正反转，将默认正转", "Warning: if forward and reverse is not selected, the default will be forward." };
        string Text1_Direction;

        string[] Speedgear_Text1 = { "错误：速度档位应为0-127。", "Error: The speed gear should be 0-127." };
        string Text1_Speedgear;

        string[] SubdivisionError_Text1 = { "错误：任意细分范围应在1-256。", "Error: Any subdivision range should be 1-256." };
        string Text1_SubdivisionError;

        string[] PulseError_Text1 = { "错误：脉冲数为16位，即0-65535", "Error: number of pulses is 16 bits, 0-65535" };
        string Text1_PulseError;

        string[] DataError_Text1 = { "警告：请选择数据类型", "Warning: Please select the data type." };
        string Text1_DataError;

        string[] EN_Text1 = { "使能", "Enable" };
        string Text1_EN;

        string[] EN_Text2 = { "没使能", "Disable" };
        string Text2_EN;

        string[] Stall_Text1 = { "堵转", "Blocked" };
        string Text1_Stall;

        string[] Stall_Text2 = { "正常", "Unblocked" };
        string Text2_Stall;

        string[] General_Text1 = { "输入超出范围", "Input out of range" };
        string Text2_General;




        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                    comboBox1.Enabled = true;
                    comboBox2.Enabled = true;
                }
                catch
                {
                    MessageBox.Show(Text1_Connect, Text1_window);
                }
                button1.Enabled = true;
                button18.Enabled = false;
            }
            else
            {
                try
                {
                    serialPort1.PortName = comboBox1.Text;
                    serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text, 10);         
                    serialPort1.Open();
                    comboBox1.Enabled = false;
                    comboBox2.Enabled = false;
                    button1.Enabled = false;
                    button18.Enabled = true;
                }
                catch
                {
                    MessageBox.Show(Text2_Connect, Text1_window);
                }
            }
        }
        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
            }
            catch
            {
                MessageBox.Show(Text1_Connect, Text1_window);
            }

            button1.Enabled = true;
            button18.Enabled = false;
        }
        private void Button_Click(object sender, EventArgs e)             //按键共用一个处理函数
        {

            Button MyButton = (Button)sender;
            DataSended = Convert.ToByte(MyButton.Tag);          
            SendRelevantData(QueryCommand[DataSended]);

        }
        private void WriteByteToSerialPort(byte[] data, byte start, byte length)
        {    //字节发送
            if (serialPort1.IsOpen)                                     
            {
                try
                {
                    serialPort1.Write(data, start, length);                    
                }
                catch
                {
                    MessageBox.Show(Text1_SerialError, Text1_window);//错误处理
                }
            }
            else
                MessageBox.Show(Text1_SerialError, Text1_window);//错误处理
        }
        private void SendRelevantData(int data)                  //判断数据类并且发送
        {
            byte Addr = Convert.ToByte(comboBox5.Text, 16);        

            byte SpeedText;                                     
            byte SpeedText2;                                     
            byte SpeedText3;                                    
            ushort SubdivisionText;                               
            uint PulseText;                                       
            ushort KpText;                                       
            ushort KiText;                                       
            ushort KdText;                                       
            ushort ACCText;                                     
            ushort MaxTText;                                     
            try
            {
                if (DataSended < 6)
                {
                    tCHK = Addr + data;                                     
                    Buffer = new byte[] { Addr, (byte)data, (byte)tCHK };                       
                    WriteByteToSerialPort(Buffer, 0, 3);

                }
                if (DataSended > 5 && DataSended < 8)                   
                {
                    if (DataSended == 6)                                
                    {
                        tCHK = Addr + data + EN_ON;                                     
                        Buffer = new byte[] { Addr, (byte)data, EN_ON, (byte)tCHK };
                        button10.Enabled = false;
                        button9.Enabled = true;
                    }
                    else                                                
                    {
                        tCHK = Addr + data + EN_OFF;                                     
                        Buffer = new byte[] { Addr, (byte)data, EN_OFF, (byte)tCHK };
                        button9.Enabled = false;
                        button10.Enabled = true;
                    }
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 8)                                        
                {
                    SpeedText = Convert.ToByte(comboBox3.Text, 10);         
                    if (SpeedText < 128 && SpeedText >= 0)
                    {
                        if (radioButton2.Checked)                          
                        {
                            Speed = Convert.ToByte(SpeedText | RWD);
                            tCHK = Addr + data + Speed;                                     
                            Buffer = new byte[] { Addr, (byte)data, Speed, (byte)tCHK };
                            //Console.WriteLine(Speed);
                        }
                        else if (radioButton1.Checked)                      
                        {
                            Speed = Convert.ToByte(SpeedText | FWD);
                            tCHK = Addr + data + Speed;
                            Buffer = new byte[] { Addr, (byte)data, Speed, (byte)tCHK };
                            //Console.WriteLine(Speed);
                        }
                        else                                               
                        {
                            MessageBox.Show(Text1_Direction, Text2_window);
                            Speed = Convert.ToByte(SpeedText | FWD);
                            tCHK = Addr + data + Speed;
                            Buffer = new byte[] { Addr, (byte)data, Speed, (byte)tCHK };
                            //Console.WriteLine(Speed);
                        }
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else
                        MessageBox.Show(Text1_Speedgear, Text1_window);
                }

                if (DataSended == 9)                    
                {
                    tCHK = Addr + STOP;
                    Buffer = new byte[] { Addr, STOP, (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 3);
                }

                if (DataSended == 10)            
                {
                    tCHK = Addr + data + Save_Speed;
                    Buffer = new byte[] { Addr, (byte)data, Save_Speed, (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                    Console.WriteLine(value: Save_Speed);
                }
                if (DataSended == 11)              
                {
                    tCHK = Addr + data + Clear_Speed;
                    Buffer = new byte[] { Addr, (byte)data, Clear_Speed, (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 12)           
                {
                    SubdivisionText = Convert.ToUInt16(comboBox22.Text, 10);
                    Console.WriteLine(SubdivisionText);
                    if (SubdivisionText < 257 && SubdivisionText >= 1)
                    {
                        Subdivision = Convert.ToByte(SubdivisionText);
                        tCHK = Addr + data + Subdivision;
                        Buffer = new byte[] { Addr, (byte)data, (byte)Subdivision, (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else
                        MessageBox.Show(Text1_SubdivisionError, Text1_window);
                }
                if (DataSended == 13)               
                {
                    SpeedText2 = Convert.ToByte(comboBox4.Text, 10);        
                    PulseText = Convert.ToUInt32(textBox8.Text, 10);        
                    Pulse = BitConverter.GetBytes(PulseText);          
                    if (SpeedText2 < 128 && SpeedText2 >= 0)
                    {
                        if (PulseText < 4294967295 && PulseText >= 1)
                        {
                            if (radioButton4.Checked)                       
                            {
                                Speed2 = Convert.ToByte(SpeedText2 | RWD);
                                //Pulse = Convert.ToByte(PulseText);
                                tCHK = Addr + data + Speed2 + Pulse[3] + Pulse[2] + Pulse[1] + Pulse[0];
                                Buffer = new byte[] { Addr, (byte)data, Speed2, Pulse[3], Pulse[2], Pulse[1], Pulse[0], (byte)tCHK };
                            }
                            else if (radioButton3.Checked)                  
                            {
                                Speed2 = Convert.ToByte(SpeedText2 | FWD);
                                //Pulse = Convert.ToByte(PulseText);
                                tCHK = Addr + data + Speed2 + Pulse[3] + Pulse[2] + Pulse[1] + Pulse[0];
                                Buffer = new byte[] { Addr, (byte)data, Speed2, Pulse[3], Pulse[2], Pulse[1], Pulse[0], (byte)tCHK };
                            }
                            else                                                       
                            {
                                MessageBox.Show(Text1_Direction, Text2_window); 
                                Speed2 = Convert.ToByte(SpeedText2 | FWD);
                                //Pulse = Convert.ToByte(PulseText);
                                tCHK = Addr + data + Speed2 + Pulse[3] + Pulse[2] + Pulse[1] + Pulse[0];
                                Buffer = new byte[] { Addr, (byte)data, Speed2, Pulse[3], Pulse[2], Pulse[1], Pulse[0], (byte)tCHK };
                            }
                            WriteByteToSerialPort(Buffer, 0, 8);
                        }
                        else
                            MessageBox.Show(Text1_PulseError, Text1_window);
                    }
                }
                if (DataSended == 14)              
                {
                    tCHK = Addr + data + byte_data[0];                                    
                    Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                       
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 15)               
                {
                    Text_BUF = comboBox6.Text;
                    if (Text_BUF == Mot_18)
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == Mot_09)
                    {
                        tCHK = Addr + data + byte_data[0];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                }
                if (DataSended == 16)               
                {
                    Text_BUF = comboBox7.Text;
                    if (Text_BUF == CR_OPEN)
                    {
                        tCHK = Addr + data + byte_data[0];                                 
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == CR_vFOC)
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                    else if (Text_BUF == CR_UART)
                    {
                        tCHK = Addr + data + byte_data[2];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                }

                if (DataSended == 17)                                                 
                {
                    Text_BUF = comboBox8.Text;
                    if (Text_BUF == I_Ma[0])
                    {
                        tCHK = Addr + data + byte_data[0];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                   
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[1])
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                  
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[2])
                    {
                        tCHK = Addr + data + byte_data[2];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };                  
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[3])
                    {
                        tCHK = Addr + data + byte_data[3];                                
                        Buffer = new byte[] { Addr, (byte)data, byte_data[3], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[4])
                    {
                        tCHK = Addr + data + byte_data[4];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[4], (byte)tCHK };                   
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[5])
                    {
                        tCHK = Addr + data + byte_data[5];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[5], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[6])
                    {
                        tCHK = Addr + data + byte_data[6];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[6], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[7])
                    {
                        tCHK = Addr + data + byte_data[7];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[7], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[8])
                    {
                        tCHK = Addr + data + byte_data[8];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[8], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[9])
                    {
                        tCHK = Addr + data + byte_data[9];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[9], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[10])
                    {
                        tCHK = Addr + data + byte_data[10];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[10], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[11])
                    {
                        tCHK = Addr + data + byte_data[11];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[11], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[12])
                    {
                        tCHK = Addr + data + byte_data[12];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[12], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[13])
                    {
                        tCHK = Addr + data + byte_data[13];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[13], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[14])
                    {
                        tCHK = Addr + data + byte_data[14];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[14], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == I_Ma[15])
                    {
                        tCHK = Addr + data + byte_data[15];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[15], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                }
                if (DataSended == 18)       
                {
                    Text_BUF = comboBox9.Text;
                    if (Text_BUF == EN_H)
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                    else if (Text_BUF == EN_L)
                    {
                        tCHK = Addr + data + byte_data[0];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == EN_Hold)
                    {
                        tCHK = Addr + data + byte_data[2];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }

                if (DataSended == 19)           
                {
                    Text_BUF = comboBox10.Text;
                    if (Text_BUF == Dir_CW)           
                    {
                        tCHK = Addr + data + byte_data[0];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                    
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                    else if (Text_BUF == Dir_CCW)      
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }
                if (DataSended == 20)         
                {
                    Text_BUF = comboBox11.Text;
                    if (Text_BUF == Disable)            
                    {
                        tCHK = Addr + data + byte_data[0];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }

                    else if (Text_BUF == Enable)    
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }
                if (DataSended == 21)         
                {
                    Text_BUF = comboBox12.Text;
                    if (Text_BUF == Disable)           
                    {
                        tCHK = Addr + data + byte_data[0];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                 
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == Enable)      
                    {
                        tCHK = Addr + data + byte_data[1];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }
                if (DataSended == 22)        
                {
                    Text_BUF = comboBox13.Text;
                    if (Text_BUF == Disable)           
                    {
                        tCHK = Addr + data + byte_data[0];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == Enable)      
                    {
                        tCHK = Addr + data + byte_data[1];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                    
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }
                if (DataSended == 23)        
                {
                    Text_BUF = comboBox14.Text;
                    if (Text_BUF == UartBaud[0])            //9600
                    {
                        tCHK = Addr + data + byte_data[1];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                  
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartBaud[1])      //19200
                    {
                        tCHK = Addr + data + byte_data[2];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartBaud[2])      //19200
                    {
                        tCHK = Addr + data + byte_data[3];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[3], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartBaud[3])      //19200
                    {
                        tCHK = Addr + data + byte_data[4];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[4], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartBaud[4])      //19200
                    {
                        tCHK = Addr + data + byte_data[5];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[5], (byte)tCHK };                    
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartBaud[5])      //19200
                    {
                        tCHK = Addr + data + byte_data[6];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[6], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }
                if (DataSended == 24)        
                {
                    Text_BUF = comboBox15.Text;
                    if (Text_BUF == UartAddr[0])            //0xE0
                    {
                        tCHK = Addr + data + byte_data[0];                                     
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };                      
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[1])      //0xE1
                    {
                        tCHK = Addr + data + byte_data[1];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[2])     //0xE2
                    {
                        tCHK = Addr + data + byte_data[2];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[3])     //0xE3
                    {
                        tCHK = Addr + data + byte_data[3];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[3], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[4])     //0xE4
                    {
                        tCHK = Addr + data + byte_data[4];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[4], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[5])    //0xE5
                    {
                        tCHK = Addr + data + byte_data[5];                                    
                        Buffer = new byte[] { Addr, (byte)data, byte_data[5], (byte)tCHK };                     
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[6])     //0xE6
                    {
                        tCHK = Addr + data + byte_data[6];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[6], (byte)tCHK };                    
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[7])     //0xE7
                    {
                        tCHK = Addr + data + byte_data[7];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[7], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[8])    //0xE8
                    {
                        tCHK = Addr + data + byte_data[8];                                  
                        Buffer = new byte[] { Addr, (byte)data, byte_data[8], (byte)tCHK };                   
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (Text_BUF == UartAddr[9])    //0xE9
                    {
                        tCHK = Addr + data + byte_data[9];                                   
                        Buffer = new byte[] { Addr, (byte)data, byte_data[9], (byte)tCHK };                       
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                }

                if (DataSended == 25)          
                {
                    KpText = Convert.ToUInt16(comboBox16.Text, 10);
                    Kp = BitConverter.GetBytes(KpText);
                    if (KpText < 65535 && KpText >= 0)
                    {
                        tCHK = Addr + data + Kp[1] + Kp[0];
                        Buffer = new byte[] { Addr, (byte)data, Kp[1], Kp[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 5);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 26)         
                {
                    KiText = Convert.ToUInt16(comboBox17.Text, 10);
                    Kp = BitConverter.GetBytes(KiText);
                    if (KiText < 65535 && KiText >= 0)
                    {
                        tCHK = Addr + data + Ki[1] + Ki[0];
                        Buffer = new byte[] { Addr, (byte)data, Ki[1], Ki[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 5);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 27)        
                {
                    KdText = Convert.ToUInt16(comboBox18.Text, 10);
                    Kd = BitConverter.GetBytes(KdText);
                    if (KdText < 65535 && KdText >= 0)
                    {
                        tCHK = Addr + data + Kd[1] + Kd[0];
                        Buffer = new byte[] { Addr, (byte)data, Kd[1], Kd[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 5);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 28)         
                {
                    ACCText = Convert.ToUInt16(comboBox19.Text, 10);
                    Kd = BitConverter.GetBytes(ACCText);
                    if (ACCText < 65535 && ACCText >= 0)
                    {
                        tCHK = Addr + data + ACC[1] + ACC[0];
                        Buffer = new byte[] { Addr, (byte)data, ACC[1], ACC[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 5);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 29)        
                {
                    MaxTText = Convert.ToUInt16(comboBox20.Text, 10);
                    Kd = BitConverter.GetBytes(MaxTText);
                    if (MaxTText < 65535 && MaxTText >= 0)
                    {
                        tCHK = Addr + data + MaxT[1] + MaxT[0];
                        Buffer = new byte[] { Addr, (byte)data, MaxT[1], MaxT[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 5);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 30)          
                {
                    if (radioButton7.Checked)                        
                    {
                        tCHK = Addr + data + byte_data[1];
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (radioButton8.Checked)
                    {
                        tCHK = Addr + data + byte_data[2];
                        Buffer = new byte[] { Addr, (byte)data, byte_data[2], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 31)        
                {
                    tCHK = Addr + data + byte_data[0];
                    Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                }

                if (DataSended == 32)        
                {
                    tCHK = Addr + data + byte_data[0];
                    Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 33)         
                {
                    SpeedText3 = Convert.ToByte(comboBox21.Text, 10);                             
                    tCHK = Addr + data + byte_data[SpeedText3];
                    Buffer = new byte[] { Addr, (byte)data, byte_data[SpeedText3], (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 34)         
                {
                    if (radioButton10.Checked)                         
                    {
                        tCHK = Addr + data + byte_data[0];
                        Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else if (radioButton9.Checked)                     
                    {
                        tCHK = Addr + data + byte_data[1];
                        Buffer = new byte[] { Addr, (byte)data, byte_data[1], (byte)tCHK };
                        WriteByteToSerialPort(Buffer, 0, 4);
                    }
                    else
                    {
                        MessageBox.Show(Text2_General, Text2_window);
                    }
                }
                if (DataSended == 35)          
                {
                    tCHK = Addr + data + byte_data[0];
                    Buffer = new byte[] { Addr, (byte)data, byte_data[0], (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 4);
                }
                if (DataSended == 36)          
                {
                    tCHK = Addr + data;
                    Buffer = new byte[] { Addr, (byte)data, (byte)tCHK };
                    WriteByteToSerialPort(Buffer, 0, 3);
                }
            }
            catch (Exception)
            { }
        }

        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialBuffer_RX = new byte[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };          
            Data_Number = serialPort1.BytesToRead;
            if (serialPort1.BytesToRead > 0)
            {
                for (int a = 0; a <= Data_Number - 1; a++)
                {
                    SerialBuffer_RX[a] = (byte)serialPort1.ReadByte();
                }

            }
            Text_display();

            /*byte Addr = Convert.ToByte(comboBox5.Text, 16);

            for (int i = 0; i <= serialPort1.BytesToRead; i++)
            {
                Readata = (byte)serialPort1.ReadByte();//此处需要强制类型转换，将(int)类型数据转换为(byte类型数据，不必考虑是否会丢失数据
                                                       //str = Convert.ToString(Readata, 10).ToUpper();//转换为十进制字符串                
                switch (DataSended)
                {
                    case 0:                             //查询编码器值

                         if (Addr == Readata)                                                //如果重新再次接受数据则先清空
                            {
                              // textBox1.Clear();
                                if (radioButton5.Checked)
                                {
                                    textBox1.AppendText("0x");
                                }
                            }


                       else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串                                                                                          
                                textBox1.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {

                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox1.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }

                            //textBox1.AppendText(str );        //十进制显示
                            //Console.WriteLine("十六进制  的十进制表示: " + Convert.ToInt32(textBox1.Text , 16));                                              //
                        }
                        break;
                    case 1:                             //输入累积脉冲数
                            (Addr == Readata && i == 0)
                                               {
                                                   textBox2.Clear();
                                                   if (radioButton5.Checked)
                                                   {
                                                       textBox2.AppendText("0x");
                                                   }
                                               }
                        if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox2.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox2.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }

                        }
                        break;

                    case 2:                                 //电机位置
                         if (Addr == Readata && i == 0)
                         {
                             textBox3.Clear();
                             if (radioButton5.Checked)
                             {
                                 textBox3.AppendText("0x");
                             }
                         }
                        if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox3.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox3.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }
                        }
                        break;

                    case 3:                         //位置角度误差
                        if (Addr == Readata)
                        {
                            textBox4.Clear();
                            if (radioButton5.Checked)
                            {
                                textBox4.AppendText("0x");
                            }
                        }
                        else if (Addr != Readata)
                        {
                            if (radioButton5.Checked)
                            {
                                str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                                textBox4.AppendText(str.Length == 1 ? "0" + str : str);//空位补“0”//十六进制显示
                            }
                            else if (radioButton6.Checked)
                            {
                                str = Convert.ToString(Readata, 10);//转换为十进制字符串
                                textBox4.AppendText(str);
                            }
                            else
                            {
                                MessageBox.Show(Text1_DataError, Text2_window);  //错误处理
                            }
                        }
                        break;

                    case 4:                                     //使能状态
                        if (Addr == Readata
                            textBox5.Clear();
                        }
                        else if (Addr != Readata)
                        {
                            if (Readata == EN_STATE_ON)
                            {
                                textBox5.AppendText(Text1_EN);
                            }
                            else if (Readata == EN_STATE_OFF)
                            {
                                textBox5.AppendText(Text2_EN);
                            }
                        }
                        break;

                    case 5:                                     //堵转状态
                        if (Addr == Readata)
                        {
                            //textBox6.Clear();
                        }
                        else if (Addr != Readata)
                        {
                            if (Readata == Stall_YES)
                            {
                                textBox6.AppendText(Text1_Stall);
                            }
                            else if (Readata == Stall_ON)
                            {
                                textBox6.AppendText(Text2_Stall);
                            }
                            //str = Convert.ToString(Readata, 16).ToUpper();//转换为大写十六进制字符串
                            //textBox6.AppendText("0x" + (str.Length == 1 ? "0" + str : str) + " ");
                        }
                        break;
                }
            }*/


        }

        private void Text_display()
        {
            word16 = Convert.ToString(SerialBuffer_RX[1], 16) + Convert.ToString(SerialBuffer_RX[2], 16);   
            data16 = Convert.ToInt16(word16, 16);
            word32 = Convert.ToString(SerialBuffer_RX[1], 16) + Convert.ToString(SerialBuffer_RX[2], 16) + Convert.ToString(SerialBuffer_RX[3], 16) + Convert.ToString(SerialBuffer_RX[4], 16);   //2个8字节字符串组成16位字符串;   //2个8字节字符串组成16位字符串
            data32 = Convert.ToInt32(word32, 16);
            switch (DataSended)
            {
                case 0:

                    if (radioButton5.Checked)
                    {
                        textBox1.Clear();
                        textBox1.AppendText("0x");
                        for (int a = 1; a < 3; a++)
                        {

                            str = Convert.ToString(SerialBuffer_RX[a], 16).ToUpper();                                                                                    
                            textBox1.AppendText(str.Length == 1 ? "0" + str : str);
                        }

                    }
                    else if (radioButton6.Checked)
                    {
                        textBox1.Clear();
                        str = Convert.ToString(data16, 10);
                        textBox1.AppendText(str);

                    }
                    else
                    {
                        MessageBox.Show(Text1_DataError, Text2_window);  
                    }

                    break;


                case 1:
                    if (radioButton5.Checked)
                    {
                        textBox2.Clear();
                        textBox2.AppendText("0x");
                        for (int a = 1; a < 5; a++)
                        {

                            str = Convert.ToString(SerialBuffer_RX[a], 16).ToUpper();                                                                                          
                            textBox2.AppendText(str.Length == 1 ? "0" + str : str);
                        }

                    }
                    else if (radioButton6.Checked)
                    {
                        textBox2.Clear();
                        str = Convert.ToString(data32, 10);
                        textBox2.AppendText(str);
                    }
                    else
                    {
                        MessageBox.Show(Text1_DataError, Text2_window);  
                    }

                    break;

                case 2:
                    if (radioButton5.Checked)
                    {
                        textBox3.Clear();
                        textBox3.AppendText("0x");
                        for (int a = 1; a < 5; a++)
                        {

                            str = Convert.ToString(SerialBuffer_RX[a], 16).ToUpper();                                                                                          
                            textBox3.AppendText(str.Length == 1 ? "0" + str : str);
                        }

                    }
                    else if (radioButton6.Checked)
                    {
                        textBox3.Clear();
                        str = Convert.ToString(data32, 10);
                        textBox3.AppendText(str);
                    }
                    else
                    {
                        MessageBox.Show(Text1_DataError, Text2_window);  
                    }
                    break;

                case 3:
                    if (radioButton5.Checked)
                    {
                        textBox4.Clear();
                        textBox4.AppendText("0x");
                        for (int a = 1; a < 3; a++)
                        {

                            str = Convert.ToString(SerialBuffer_RX[a], 16).ToUpper();                                                                                          
                            textBox4.AppendText(str.Length == 1 ? "0" + str : str);
                        }

                    }
                    else if (radioButton6.Checked)
                    {
                        textBox4.Clear();
                        str = Convert.ToString(data16, 10);
                        textBox4.AppendText(str);
                    }
                    else
                    {
                        MessageBox.Show(Text1_DataError, Text2_window);  
                    }
                    break;
                case 4:
                    if (SerialBuffer_RX[1] == EN_STATE_ON)
                    {
                        textBox5.Clear();
                        textBox5.AppendText(Text1_EN);
                    }
                    else if (SerialBuffer_RX[1] == EN_STATE_OFF)
                    {
                        textBox5.Clear();
                        textBox5.AppendText(Text2_EN);
                    }
                    break;
                case 5:
                    if (SerialBuffer_RX[1] == Stall_YES)
                    {
                        textBox6.Clear();
                        textBox6.AppendText(Text1_Stall);
                    }
                    else if (SerialBuffer_RX[1] == Stall_ON)
                    {
                        textBox6.Clear();
                        textBox6.AppendText(Text2_Stall);
                    }
                    break;

            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }



        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);       //扫描并讲课用串口添加至下拉列表
        }
        private void SearchAndAddSerialToComboBox(SerialPort MyPort, ComboBox MyBox)
        {                                                               //将可用端口号添加到ComboBox
            //string[] MyString = new string[20];                         //最多容纳20个，太多会影响调试效率
            string Buffer;                                              //缓存
            MyBox.Items.Clear();                                        //清空ComboBox内容

            for (int i = 1; i < 20; i++)                                //循环
            {
                try                                                     //核心原理是依靠try和catch完成遍历
                {
                    Buffer = "COM" + i.ToString();
                    MyPort.PortName = Buffer;
                    MyPort.Open();                                      //如果失败，后面的代码不会执行
                    MyBox.Items.Add(Buffer);                            //打开成功，添加至下俩列表
                    MyPort.Close();                                     //关闭
                }
                catch
                {

                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void Form1_Load_1(object sender, EventArgs e)
        {
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);
            comboBox2.Text = "38400";//波特率默认值
            comboBox5.Text = "0xE0";
            comboBox3.Text = "000";
            comboBox4.Text = "000";
            textBox8.Text = "0";
            /*****************语言默认************************/
            groupBox1.Text = "Setting";
            groupBox2.Text = "Read parameters";
            groupBox3.Text = "Set PID/ACC/Torque parameters";
            groupBox4.Text = "Motor control";
            groupBox5.Text = "Control motor rotation";
            groupBox6.Text = "Control motor position";
            groupBox7.Text = "Set system parameters";
            groupBox8.Text = "PID parameters";
            groupBox9.Text = "Acceleration parameter";
            groupBox10.Text = "Maximum torque";
            groupBox11.Text = "Set auto zero";


            label1.Text = "MStep";
            label2.Text = "Port";
            label3.Text = "Baud rate";
            label4.Text = "Speed gear";
            label5.Text = "Speed gear";
            label6.Text = "Pulses number";
            label7.Text = "Tip: At 16 subdivision, 3200 pulses = 360°";
            label8.Text = "En";
            label9.Text = "Address";
            label10.Text = "Tip: Speed gear range 0-127";
            label11.Text = "MotType";
            label12.Text = "CtrMode";
            label13.Text = "Ma";
            label14.Text = "Dir";
            label15.Text = "AutoSDD";
            label16.Text = "Protect";
            label17.Text = "MPlyer";
            label18.Text = "UartBaud";
            label19.Text = "UartAddr";
            label20.Text = "Note: Improper setting of parameters here may damage the motherboard,please set it carefully and don't modify it if you are not sure.";
            //label31.Text = "please set it carefully and don't modify it if you are not sure.";
            label21.Text = "Kp";
            label22.Text = "Ki";
            label23.Text = "Kd";
            label24.Text = "ACC";
            label25.Text = "Torque";
            label26.Text = "0_Mode";
            label27.Text = "Please manually turn the motor shaft to the zero position to be set, and then click OK.";
            label28.Text = "0_Speed";
            label29.Text = "0_Dir";
            label30.Text = "Note: After clicking 'Factory reset', you need to power on again.";


            button1.Text = "Connect";
            button2.Text = "Verify";
            button3.Text = "Encoder value";
            button4.Text = "Cumulative pulse number";
            button5.Text = "Motor position";
            button6.Text = "Position angle error";
            button7.Text = "Driver board enable state";
            button8.Text = "Blocked";
            button9.Text = "Disable enable";
            button10.Text = "Enable driver board";
            button11.Text = "Start";
            button12.Text = "Stop";
            button13.Text = "Turn on automatic operation after power-on";
            button14.Text = "Turn off automatic operation after power-on";
            button15.Text = "Start";
            button16.Text = "Stop";
            button17.Text = "Scan";
            button18.Text = "Disconnect";
            button19.Text = "Cal";
            button20.Text = "Verify";
            button21.Text = "Verify";
            button22.Text = "Verify";
            button23.Text = "Verify";
            button24.Text = "Verify";
            button25.Text = "Verify";
            button26.Text = "Verify";
            button27.Text = "Verify";
            button28.Text = "Verify";
            button29.Text = "Verify";
            button30.Text = "Verify";
            button31.Text = "Verify";
            button32.Text = "Verify";
            button33.Text = "Verify";
            button34.Text = "Verify";
            button35.Text = "Enable";
            button36.Text = "Disable";
            button37.Text = "OK";
            button38.Text = "Verify";
            button39.Text = "Verify";
            button40.Text = "Return to zero";
            button41.Text = "Factory reset";

            radioButton1.Text = "Forward";
            radioButton2.Text = "Reverse";
            radioButton3.Text = "Forward";
            radioButton4.Text = "Reverse";
            radioButton5.Text = "Hex";
            radioButton6.Text = "Decimal";
            radioButton7.Text = "DirMode";
            radioButton8.Text = "NearMode";
            radioButton9.Text = "Reverse";
            radioButton10.Text = "Forward";


            语言ToolStripMenuItem.Text = "Language";

            Text1_Connect = ConnectText1[1];
            Text1_window = WindowText1[1];
            Text2_window = WindowText2[1];
            Text2_Connect = ConnectText2[1];
            Text1_SerialError = SerialErrorText1[1];
            Text1_Direction = Direction_Text[1];
            Text1_Speedgear = Speedgear_Text1[1];
            Text1_SubdivisionError = SubdivisionError_Text1[1];
            Text1_PulseError = PulseError_Text1[1];
            Text1_DataError = DataError_Text1[1];
            Text1_EN = EN_Text1[1];
            Text2_EN = EN_Text2[1];
            Text1_Stall = Stall_Text1[1];
            Text2_Stall = Stall_Text2[1];
            /*****************非常重要************************/
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);//必须手动添加事件处理程序
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void 设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 中文ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            groupBox1.Text = "连接设置";
            groupBox2.Text = "读取参数";
            groupBox3.Text = "设置PID/加速度/扭矩参数";
            groupBox4.Text = "电机控制";
            groupBox5.Text = "控制电机正反转";
            groupBox6.Text = "控制电机位置";
            groupBox7.Text = "设置系统参数";
            groupBox8.Text = "PID参数";
            groupBox9.Text = "加速度参数";
            groupBox10.Text = "最大扭矩";
            groupBox11.Text = "设置自动回零";


            label1.Text = "细分设置";
            label2.Text = "串  口";
            label3.Text = "波特率";
            label4.Text = "速度档位";
            label5.Text = "速度档位";
            label6.Text = "脉冲数";
            label7.Text = "提示：在16细分时，3200脉冲 = 360°";
            label8.Text = "使能设置";
            label9.Text = "通讯地址";
            label10.Text = "提示：速度档位范围0-127";
            label11.Text = "电机类型";
            label12.Text = "工作模式";
            label13.Text = "电流值(mA)";
            label14.Text = "电机方向";
            label15.Text = "自动息屏";
            label16.Text = "堵转保护";
            label17.Text = "细分插补";
            label18.Text = "串口波特率";
            label19.Text = "通讯地址";
            label20.Text = "注意:此处的参数设置不当，可能会损坏主板，请谨慎设置，如果不确定，请不要修改。";
            //label31.Text = "请谨慎设置，如果不确定，请不要修改。";
            label21.Text = "位置Kp";
            label22.Text = "位置Ki";
            label23.Text = "位置Kd";
            label24.Text = "加速度";
            label25.Text = "扭矩";
            label26.Text = "回零模式";
            label27.Text = "请手动将电机轴转至需要设置的零点位置，然后点击确认。";
            label28.Text = "回零速度";
            label29.Text = "回零方向";
            label30.Text = "注意：点击“恢复出厂设置”后需要重新上电。";

            button1.Text = "连接主板";
            button2.Text = "确认";
            button3.Text = "编码器值";
            button4.Text = "输入累计脉冲数";
            button5.Text = "电机位置";
            button6.Text = "位置角度误差";
            button7.Text = "驱动板使能状态";
            button8.Text = "堵转标志位";
            button9.Text = "关闭驱动板";
            button10.Text = "使能驱动板";
            button11.Text = "开始";
            button12.Text = "停止";
            button13.Text = "开启上电自动运行";
            button14.Text = "关闭上电自动运行";
            button15.Text = "开始";
            button16.Text = "停止";
            button17.Text = "扫描";
            button18.Text = "断开连接";
            button19.Text = "校准";
            button20.Text = "确认";
            button21.Text = "确认";
            button22.Text = "确认";
            button23.Text = "确认";
            button24.Text = "确认";
            button25.Text = "确认";
            button26.Text = "确认";
            button27.Text = "确认";
            button28.Text = "确认";
            button29.Text = "确认";
            button30.Text = "确认";
            button31.Text = "确认";
            button32.Text = "确认";
            button33.Text = "确认";
            button34.Text = "确认";
            button35.Text = "开启";
            button36.Text = "关闭";
            button37.Text = "确认";
            button38.Text = "确认";
            button39.Text = "确认";
            button40.Text = "返回零点";
            button41.Text = "恢复出厂配置";


            radioButton1.Text = "正转";
            radioButton2.Text = "反转";
            radioButton3.Text = "正转";
            radioButton4.Text = "反转";
            radioButton5.Text = "十六进制";
            radioButton6.Text = "十进制";
            radioButton7.Text = "方向模式";
            radioButton8.Text = "就近模式";
            radioButton9.Text = "反转";
            radioButton10.Text = "正转";



            语言ToolStripMenuItem.Text = "语言";

            Text1_Connect = ConnectText1[0];
            Text2_Connect = ConnectText2[0];
            Text1_window = WindowText1[0];
            Text2_window = WindowText2[0];
            Text1_SerialError = SerialErrorText1[0];
            Text1_Direction = Direction_Text[0];
            Text1_Speedgear = Speedgear_Text1[0];
            Text1_SubdivisionError = SubdivisionError_Text1[0];
            Text1_PulseError = PulseError_Text1[0];
            Text1_DataError = DataError_Text1[0];
            Text1_EN = EN_Text1[0];
            Text2_EN = EN_Text2[0];
            Text1_Stall = Stall_Text1[0];
            Text2_Stall = Stall_Text2[0];
        }

        private void englishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Text = "Setting";
            groupBox2.Text = "Read parameters";
            groupBox3.Text = "Set PID/ACC/Torque parameters";
            groupBox4.Text = "Motor control";
            groupBox5.Text = "Control motor rotation";
            groupBox6.Text = "Control motor position";
            groupBox7.Text = "Set system parameters";
            groupBox8.Text = "PID parameters";
            groupBox9.Text = "Acceleration parameter";
            groupBox10.Text = "Maximum torque";
            groupBox11.Text = "Set auto zero";


            label1.Text = "MStep";
            label2.Text = "Port";
            label3.Text = "Baud rate";
            label4.Text = "Speed gear";
            label5.Text = "Speed gear";
            label6.Text = "Pulses number";
            label7.Text = "Tip: At 16 subdivision, 3200 pulses = 360°";
            label8.Text = "En";
            label9.Text = "Address";
            label10.Text = "Tip: Speed gear range 0-127";
            label11.Text = "MotType";
            label12.Text = "CtrMode";
            label13.Text = "Ma";
            label14.Text = "Dir";
            label15.Text = "AutoSDD";
            label16.Text = "Protect";
            label17.Text = "MPlyer";
            label18.Text = "UartBaud";
            label19.Text = "UartAddr";
            label20.Text = "Note: Improper setting of parameters here may damage the motherboard,please set it carefully and don't modify it if you are not sure.";
            //label31.Text = "please set it carefully and don't modify it if you are not sure.";
            label21.Text = "Kp";
            label22.Text = "Ki";
            label23.Text = "Kd";
            label24.Text = "ACC";
            label25.Text = "Torque";
            label26.Text = "0_Mode";
            label27.Text = "Please manually turn the motor shaft to the zero position to be set, and then click OK.";
            label28.Text = "0_Speed";
            label29.Text = "0_Dir";
            label30.Text = "Note: After clicking 'Factory reset', you need to power on again.";


            button1.Text = "Connect";
            button2.Text = "Verify";
            button3.Text = "Encoder value";
            button4.Text = "Cumulative pulse number";
            button5.Text = "Motor position";
            button6.Text = "Position angle error";
            button7.Text = "Driver board enable state";
            button8.Text = "Blocked";
            button9.Text = "Disable enable";
            button10.Text = "Enable driver board";
            button11.Text = "Start";
            button12.Text = "Stop";
            button13.Text = "Turn on automatic operation after power-on";
            button14.Text = "Turn off automatic operation after power-on";
            button15.Text = "Start";
            button16.Text = "Stop";
            button17.Text = "Scan";
            button18.Text = "Disconnect";
            button19.Text = "Cal";
            button20.Text = "Verify";
            button21.Text = "Verify";
            button22.Text = "Verify";
            button23.Text = "Verify";
            button24.Text = "Verify";
            button25.Text = "Verify";
            button26.Text = "Verify";
            button27.Text = "Verify";
            button28.Text = "Verify";
            button29.Text = "Verify";
            button30.Text = "Verify";
            button31.Text = "Verify";
            button32.Text = "Verify";
            button33.Text = "Verify";
            button34.Text = "Verify";
            button35.Text = "Enable";
            button36.Text = "Disable";
            button37.Text = "OK";
            button38.Text = "Verify";
            button39.Text = "Verify";
            button40.Text = "Return to zero";
            button41.Text = "Factory reset";

            radioButton1.Text = "Forward";
            radioButton2.Text = "Reverse";
            radioButton3.Text = "Forward";
            radioButton4.Text = "Reverse";
            radioButton5.Text = "Hex";
            radioButton6.Text = "Decimal";
            radioButton7.Text = "DirMode";
            radioButton8.Text = "NearMode";
            radioButton9.Text = "Reverse";
            radioButton10.Text = "Forward";


            语言ToolStripMenuItem.Text = "Language";

            Text1_Connect = ConnectText1[1];
            Text1_window = WindowText1[1];
            Text2_window = WindowText2[1];
            Text2_Connect = ConnectText2[1];
            Text1_SerialError = SerialErrorText1[1];
            Text1_Direction = Direction_Text[1];
            Text1_Speedgear = Speedgear_Text1[1];
            Text1_SubdivisionError = SubdivisionError_Text1[1];
            Text1_PulseError = PulseError_Text1[1];
            Text1_DataError = DataError_Text1[1];
            Text1_EN = EN_Text1[1];
            Text2_EN = EN_Text2[1];
            Text1_Stall = Stall_Text1[1];
            Text2_Stall = Stall_Text2[1];
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void button41_Click(object sender, EventArgs e)
        {

        }
    }
}
